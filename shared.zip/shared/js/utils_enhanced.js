// Enhanced Shared JavaScript Utilities for Financial System

// ⚠️ SECURITY WARNING
console.log(`%c
╔══════════════════════════════════════════════════════════════╗
║                    ⚠️ SECURE SYSTEM ⚠️                       ║
╠══════════════════════════════════════════════════════════════╣
║  PRODUCTION FINANCIAL SYSTEM                                ║
║  Owner: Olawale Abdul-Ganiyu                                  ║
║  Status: RESTRICTED ACCESS - OWNER ONLY                       ║
╠══════════════════════════════════════════════════════════════╣
║  UNAUTHORIZED ACCESS WILL BE BLOCKED IMMEDIATELY            ║
║  All networks are monitored and logged                       ║
╚══════════════════════════════════════════════════════════════╝
`, 'background: #000088; color: white; font-size: 14px; font-weight: bold;');

// Local Storage Management
const Storage = {
    save: (key, data) => {
        try {
            localStorage.setItem(key, JSON.stringify(data));
            return true;
        } catch (error) {
            console.error('Storage save error:', error);
            return false;
        }
    },
    
    load: (key) => {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error('Storage load error:', error);
            return null;
        }
    },
    
    remove: (key) => {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.error('Storage remove error:', error);
            return false;
        }
    }
};

// Authentication System - OWNER ONLY
const Auth = {
    // Owner information - ONLY AUTHORIZED USER
    owner: {
        name: 'Olawale Abdul-Ganiyu',
        phone: '+2348163055848',
        bvn: '22203477535',
        nin: '87142812384',
        role: 'admin',
        email: 'owner@pilgrimcoin.system'
    },
    
    // Check if current user is owner
    isOwner: (phone, bvn) => {
        return phone === Auth.owner.phone && bvn === Auth.owner.bvn;
    },
    
    // Check if current user is owner with NIN
    isOwnerWithNIN: (phone, bvn, nin) => {
        return phone === Auth.owner.phone && 
               bvn === Auth.owner.bvn && 
               nin === Auth.owner.nin;
    },
    
    // Login function - ONLY OWNER CAN LOGIN
    login: (phone, bvn, nin = null) => {
        // Immediate network security check
        NetworkMonitor.performSecurityCheck();
        
        if (nin) {
            if (Auth.isOwnerWithNIN(phone, bvn, nin)) {
                Storage.save('currentUser', Auth.owner);
                NetworkMonitor.logAuthorizedAccess();
                return { success: true, user: Auth.owner };
            }
        } else {
            if (Auth.isOwner(phone, bvn)) {
                Storage.save('currentUser', Auth.owner);
                NetworkMonitor.logAuthorizedAccess();
                return { success: true, user: Auth.owner };
            }
        }
        
        // Log failed login attempt
        NetworkMonitor.logUnauthorizedAttempt(phone, bvn);
        
        return { 
            success: false, 
            message: 'ACCESS DENIED. Only Olawale Abdul-Ganiyu is authorized to access this system.' 
        };
    },
    
    // Register function - ONLY OWNER CAN REGISTER
    register: (phone, bvn, nin, name) => {
        // Block all registration attempts except owner
        if (phone !== Auth.owner.phone || bvn !== Auth.owner.bvn || name !== Auth.owner.name) {
            NetworkMonitor.logBlockedRegistration(phone, bvn, name);
            return {
                success: false,
                message: 'REGISTRATION BLOCKED. This is a private system. Only Olawale Abdul-Ganiyu can register.'
            };
        }
        
        // Register owner
        Storage.save('currentUser', Auth.owner);
        NetworkMonitor.logAuthorizedAccess();
        return { success: true, user: Auth.owner };
    },
    
    // Logout function
    logout: () => {
        Storage.remove('currentUser');
        return { success: true };
    },
    
    // Check if logged in
    isLoggedIn: () => {
        const user = Storage.load('currentUser');
        if (!user) return false;
        
        // Verify it's still the owner
        return user.name === Auth.owner.name && 
               user.phone === Auth.owner.phone;
    },
    
    // Get current user
    getCurrentUser: () => {
        const user = Storage.load('currentUser');
        if (!user) return null;
        
        // Verify it's still the owner
        if (user.name === Auth.owner.name && user.phone === Auth.owner.phone) {
            return user;
        }
        
        // Clear invalid user
        Storage.remove('currentUser');
        return null;
    },
    
    // Verify access on every page load
    verifyAccess: () => {
        if (!Auth.isLoggedIn()) {
            console.error('ACCESS DENIED - Not logged in');
            return false;
        }
        
        // Verify user is still owner
        const user = Auth.getCurrentUser();
        if (!user || user.name !== Auth.owner.name) {
            console.error('ACCESS DENIED - Invalid user session');
            Storage.remove('currentUser');
            return false;
        }
        
        // Perform security check
        NetworkMonitor.performSecurityCheck();
        
        return true;
    }
};

// Account Number Generator
const AccountGenerator = {
    // Generate 10-digit account number
    generateAccountNumber: () => {
        let accountNumber;
        do {
            accountNumber = Math.floor(1000000000 + Math.random() * 9000000000).toString();
        } while (AccountGenerator.isAccountNumberExists(accountNumber));
        return accountNumber;
    },
    
    // Generate serial number (2 letters + 8 digits)
    generateSerialNumber: () => {
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const randomLetters = Array.from({length: 2}, () => 
            letters[Math.floor(Math.random() * letters.length)]
        ).join('');
        const randomDigits = Math.floor(10000000 + Math.random() * 90000000).toString();
        return randomLetters + randomDigits;
    },
    
    // Check if account number exists (in storage)
    isAccountNumberExists: (accountNumber) => {
        const customers = Storage.load('bankCustomers') || [];
        return customers.some(c => c.accountNumber === accountNumber);
    }
};

// Crypto Wallet Generator
const CryptoWallet = {
    // Generate Ethereum-style wallet address
    generateAddress: () => {
        const prefix = '0x';
        const chars = '0123456789abcdef';
        let address = prefix;
        for (let i = 0; i < 40; i++) {
            address += chars[Math.floor(Math.random() * chars.length)];
        }
        return address;
    },
    
    // Generate private key (simulation - NOT secure for production)
    generatePrivateKey: () => {
        const chars = '0123456789abcdef';
        let key = '';
        for (let i = 0; i < 64; i++) {
            key += chars[Math.floor(Math.random() * chars.length)];
        }
        return key;
    },
    
    // Generate complete wallet
    generateWallet: (blockchainType) => {
        return {
            address: CryptoWallet.generateAddress(),
            privateKey: CryptoWallet.generatePrivateKey(),
            blockchain: blockchainType,
            createdAt: new Date().toISOString()
        };
    }
};

// Transaction Manager
const TransactionManager = {
    // Create transaction
    create: (from, to, amount, type, metadata = {}) => {
        // Verify access
        if (!Auth.verifyAccess()) {
            console.error('Transaction blocked - Unauthorized access');
            return null;
        }
        
        const transaction = {
            id: Date.now().toString(),
            from,
            to,
            amount,
            type,
            status: 'pending',
            metadata,
            createdAt: new Date().toISOString()
        };
        
        // Save transaction
        const transactions = Storage.load('transactions') || [];
        transactions.push(transaction);
        Storage.save('transactions', transactions);
        
        return transaction;
    },
    
    // Get all transactions
    getAll: () => {
        if (!Auth.verifyAccess()) return [];
        return Storage.load('transactions') || [];
    },
    
    // Get transactions by type
    getByType: (type) => {
        if (!Auth.verifyAccess()) return [];
        const transactions = Storage.load('transactions') || [];
        return transactions.filter(t => t.type === type);
    },
    
    // Get transactions by account
    getByAccount: (accountNumber) => {
        if (!Auth.verifyAccess()) return [];
        const transactions = Storage.load('transactions') || [];
        return transactions.filter(t => 
            t.from === accountNumber || t.to === accountNumber
        );
    }
};

// Notification System
const NotificationSystem = {
    // Send credit alert
    sendCreditAlert: (recipient, amount, source) => {
        if (!Auth.verifyAccess()) return null;
        
        const alert = {
            id: Date.now().toString(),
            type: 'credit',
            recipient,
            amount,
            source,
            message: `Credit Alert: ${amount} received from ${source}`,
            timestamp: new Date().toISOString(),
            read: false
        };
        
        const notifications = Storage.load('notifications') || [];
        notifications.push(alert);
        Storage.save('notifications', notifications);
        
        console.log(`📧 EMAIL ALERT: ${alert.message}`);
        console.log(`📱 SMS ALERT: ${alert.message}`);
        
        return alert;
    },
    
    // Send debit alert
    sendDebitAlert: (account, amount, destination) => {
        if (!Auth.verifyAccess()) return null;
        
        const alert = {
            id: Date.now().toString(),
            type: 'debit',
            account,
            amount,
            destination,
            message: `Debit Alert: ${amount} sent to ${destination}`,
            timestamp: new Date().toISOString(),
            read: false
        };
        
        const notifications = Storage.load('notifications') || [];
        notifications.push(alert);
        Storage.save('notifications', notifications);
        
        console.log(`📧 EMAIL ALERT: ${alert.message}`);
        console.log(`📱 SMS ALERT: ${alert.message}`);
        
        return alert;
    },
    
    // Get unread notifications
    getUnread: () => {
        if (!Auth.verifyAccess()) return [];
        const notifications = Storage.load('notifications') || [];
        return notifications.filter(n => !n.read);
    },
    
    // Mark as read
    markAsRead: (notificationId) => {
        if (!Auth.verifyAccess()) return;
        const notifications = Storage.load('notifications') || [];
        const index = notifications.findIndex(n => n.id === notificationId);
        if (index !== -1) {
            notifications[index].read = true;
            Storage.save('notifications', notifications);
        }
    }
};

// Market Regulation System
const MarketRegulator = {
    currentPrice: 0.50, // Initial price in USD
    priceHistory: [],
    marketTrend: 'stable',
    volatility: 0.05,
    
    // Initialize market
    initialize: () => {
        // Load price history or create initial
        const savedHistory = Storage.load('priceHistory');
        if (savedHistory) {
            MarketRegulator.priceHistory = savedHistory;
            MarketRegulator.currentPrice = savedHistory[savedHistory.length - 1].price;
        } else {
            // Initialize with some history
            for (let i = 0; i < 24; i++) {
                const price = 0.48 + Math.random() * 0.04;
                MarketRegulator.priceHistory.push({
                    price: price,
                    timestamp: new Date(Date.now() - (24 - i) * 3600000).toISOString()
                });
            }
            Storage.save('priceHistory', MarketRegulator.priceHistory);
        }
        
        // Start price updates
        MarketRegulator.startRegulation();
    },
    
    // Start price regulation
    startRegulation: () => {
        setInterval(MarketRegulator.updatePrice, 60000); // Update every minute
    },
    
    // Update price
    updatePrice: () => {
        const change = (Math.random() - 0.5) * MarketRegulator.volatility * 2;
        let newPrice = MarketRegulator.currentPrice + change;
        
        // Keep price in reasonable range
        newPrice = Math.max(0.30, Math.min(0.70, newPrice));
        
        // Update market trend
        if (newPrice > MarketRegulator.currentPrice * 1.01) {
            MarketRegulator.marketTrend = 'rising';
        } else if (newPrice < MarketRegulator.currentPrice * 0.99) {
            MarketRegulator.marketTrend = 'falling';
        } else {
            MarketRegulator.marketTrend = 'stable';
        }
        
        MarketRegulator.currentPrice = newPrice;
        
        // Add to history
        MarketRegulator.priceHistory.push({
            price: newPrice,
            trend: MarketRegulator.marketTrend,
            timestamp: new Date().toISOString()
        });
        
        // Keep only last 100 entries
        if (MarketRegulator.priceHistory.length > 100) {
            MarketRegulator.priceHistory = MarketRegulator.priceHistory.slice(-100);
        }
        
        // Save
        Storage.save('priceHistory', MarketRegulator.priceHistory);
        Storage.save('currentPrice', newPrice);
        Storage.save('marketTrend', MarketRegulator.marketTrend);
        
        console.log(`📈 Market Update: PLC = $${newPrice.toFixed(4)} (${MarketRegulator.marketTrend})`);
    },
    
    // Get current price
    getCurrentPrice: () => {
        return MarketRegulator.currentPrice;
    },
    
    // Get price history
    getPriceHistory: () => {
        return MarketRegulator.priceHistory;
    },
    
    // Get market trend
    getMarketTrend: () => {
        return MarketRegulator.marketTrend;
    },
    
    // Simulate market volatility
    simulateVolatility: (factor = 1.0) => {
        MarketRegulator.volatility = 0.05 * factor;
        console.log(`📊 Volatility adjusted: ${(MarketRegulator.volatility * 100).toFixed(1)}%`);
    }
};

// Enhanced Network Monitor - STRICT SECURITY
const NetworkMonitor = {
    activeConnections: [],
    authorizedDevices: ['OWNER_DEVICE_001'],
    securityLevel: 'MAXIMUM',
    
    // Perform security check - RUNS ON EVERY PAGE LOAD
    performSecurityCheck: () => {
        const currentUser = Storage.load('currentUser');
        if (!currentUser) {
            console.error('SECURITY ALERT: No user logged in');
            return false;
        }
        
        if (currentUser.name !== 'Olawale Abdul-Ganiyu') {
            NetworkMonitor.blockAccess('Unauthorized user detected');
            return false;
        }
        
        // Detect current device
        const deviceInfo = NetworkMonitor.detectDeviceInfo();
        
        // Log access
        console.log(`✅ Security Check Passed - User: ${currentUser.name}, Device: ${deviceInfo.device}`);
        
        return true;
    },
    
    // Log authorized access
    logAuthorizedAccess: () => {
        const deviceInfo = NetworkMonitor.detectDeviceInfo();
        const accessLog = {
            ...deviceInfo,
            timestamp: new Date().toISOString(),
            status: 'authorized',
            user: 'Olawale Abdul-Ganiyu'
        };
        
        const accessLogs = Storage.load('accessLogs') || [];
        accessLogs.push(accessLog);
        Storage.save('accessLogs', accessLogs);
    },
    
    // Log unauthorized login attempt
    logUnauthorizedAttempt: (phone, bvn) => {
        const deviceInfo = NetworkMonitor.detectDeviceInfo();
        const attemptLog = {
            phone,
            bvn,
            ...deviceInfo,
            timestamp: new Date().toISOString(),
            status: 'blocked',
            reason: 'Unauthorized login attempt'
        };
        
        const blockedAttempts = Storage.load('blockedAttempts') || [];
        blockedAttempts.push(attemptLog);
        Storage.save('blockedAttempts', blockedAttempts);
        
        console.error(`🚨 BLOCKED: Unauthorized login attempt from ${phone}`);
    },
    
    // Log blocked registration
    logBlockedRegistration: (phone, bvn, name) => {
        const deviceInfo = NetworkMonitor.detectDeviceInfo();
        const registrationLog = {
            phone,
            bvn,
            name,
            ...deviceInfo,
            timestamp: new Date().toISOString(),
            status: 'blocked',
            reason: 'Registration not allowed - system is private'
        };
        
        const blockedRegistrations = Storage.load('blockedRegistrations') || [];
        blockedRegistrations.push(registrationLog);
        Storage.save('blockedRegistrations', blockedRegistrations);
        
        console.error(`🚨 BLOCKED: Registration attempt by ${name} (${phone})`);
    },
    
    // Add connection with enhanced device detection
    addConnection: (ip, location, userAgent) => {
        // Verify access first
        if (!Auth.verifyAccess()) {
            return null;
        }
        
        // Detect device information
        const deviceInfo = NetworkMonitor.detectDeviceInfo();
        
        const connection = {
            id: Date.now().toString(),
            ip,
            location,
            userAgent,
            ...deviceInfo,
            timestamp: new Date().toISOString(),
            status: 'active',
            authorized: NetworkMonitor.isAuthorized(deviceInfo)
        };
        
        // Check if connection is authorized
        if (!connection.authorized) {
            NetworkMonitor.blockUnauthorizedConnection(connection);
            return null;
        }
        
        NetworkMonitor.activeConnections.push(connection);
        
        if (NetworkMonitor.activeConnections.length > 1) {
            NetworkMonitor.triggerAlarm();
        }
        
        return connection;
    },
    
    // Detect device information
    detectDeviceInfo: () => {
        const ua = navigator.userAgent;
        const platform = navigator.platform;
        
        return {
            address: NetworkMonitor.getIPAddress(),
            map: 'https://maps.google.com/?q=' + NetworkMonitor.getIPAddress(),
            navigation: navigator.language || 'Unknown',
            device: NetworkMonitor.getDeviceType(ua),
            model: platform || 'Unknown',
            imei1: NetworkMonitor.generateIMEI(),
            imei2: NetworkMonitor.generateIMEI(),
            serial: NetworkMonitor.generateSerial(),
            network: navigator.connection ? navigator.connection.effectiveType : 'Unknown',
            ethernet: navigator.connection ? navigator.connection.type === 'ethernet' : false,
            internet: navigator.onLine,
            wifi: navigator.connection ? navigator.connection.type === 'wifi' : false,
            Bluetooth: navigator.bluetooth ? 'Available' : 'Not Available',
            wireless: navigator.connection ? navigator.connection.type !== 'ethernet' : true,
            software: navigator.appVersion,
            browser: NetworkMonitor.getBrowserName(ua),
            app: 'Financial System',
            phone: /Mobi|Android/i.test(ua),
            desktop: !/Mobi|Android/i.test(ua),
            laptop: /Laptop|Notebook/i.test(ua),
            gadgets: /Mobile|Tablet/i.test(ua),
            cable: navigator.connection ? navigator.connection.type === 'ethernet' : false,
            analys: 'Active',
            edit: false,
            login: true,
            copy: false,
            paste: false,
            add: false,
            remove: false,
            fraud: false
        };
    },
    
    // Get device type
    getDeviceType: (ua) => {
        if (/Mobile|Android|iPhone/i.test(ua)) return 'Mobile';
        if (/Tablet|iPad/i.test(ua)) return 'Tablet';
        if (/Laptop|Notebook/i.test(ua)) return 'Laptop';
        return 'Desktop';
    },
    
    // Get browser name
    getBrowserName: (ua) => {
        if (/Chrome/i.test(ua)) return 'Chrome';
        if (/Firefox/i.test(ua)) return 'Firefox';
        if (/Safari/i.test(ua)) return 'Safari';
        if (/Edge/i.test(ua)) return 'Edge';
        return 'Unknown';
    },
    
    // Generate IMEI (simulation)
    generateIMEI: () => {
        return Math.floor(Math.random() * 900000000000000).toString().padStart(15, '0');
    },
    
    // Generate serial number (simulation)
    generateSerial: () => {
        return 'SN-' + Math.random().toString(36).substring(2, 15).toUpperCase();
    },
    
    // Get IP address (simulation)
    getIPAddress: () => {
        return '192.168.1.' + Math.floor(Math.random() * 255);
    },
    
    // Check if device is authorized - OWNER ONLY
    isAuthorized: (deviceInfo) => {
        const currentUser = Storage.load('currentUser');
        if (!currentUser) return false;
        
        // Only owner device is authorized
        return currentUser.name === 'Olawale Abdul-Ganiyu' && 
               currentUser.phone === '+2348163055848';
    },
    
    // Block unauthorized connection
    blockUnauthorizedConnection: (connection) => {
        const alert = `
        ╔══════════════════════════════════════════════════════════════╗
        ║              🛡️ ACCESS BLOCKED 🛡️                           ║
        ╠══════════════════════════════════════════════════════════════╣
        ║  This system is PRIVATE and RESTRICTED                       ║
        ║                                                              ║
        ║  Only Olawale Abdul-Ganiyu is authorized                    ║
        ║  Phone: +2348163055848                                       ║
        ║  BVN: 22203477535                                             ║
        ║                                                              ║
        ║  Your connection has been blocked and logged                 ║
        ╚══════════════════════════════════════════════════════════════╝
        `;
        
        console.error(alert);
        
        // Log the unauthorized attempt
        const unauthorizedLog = Storage.load('unauthorizedLog') || [];
        unauthorizedLog.push({
            ...connection,
            blockedAt: new Date().toISOString(),
            reason: 'Unauthorized device - Owner only access'
        });
        Storage.save('unauthorizedLog', unauthorizedLog);
        
        // Redirect to access denied page
        alert('ACCESS BLOCKED\n\nThis is a private financial system.\nOnly Olawale Abdul-Ganiyu is authorized to access this system.\n\nYour IP has been logged.');
        window.location.href = 'index.html';
    },
    
    // Block access immediately
    blockAccess: (reason) => {
        console.error(`🚨 ACCESS BLOCKED: ${reason}`);
        Storage.remove('currentUser');
        alert(`ACCESS BLOCKED\n\n${reason}\n\nOnly Olawale Abdul-Ganiyu can access this system.`);
        window.location.href = 'index.html';
    },
    
    // Remove connection
    removeConnection: (connectionId) => {
        NetworkMonitor.activeConnections = NetworkMonitor.activeConnections.filter(
            c => c.id !== connectionId
        );
    },
    
    // Get all connections
    getAllConnections: () => {
        if (!Auth.verifyAccess()) return [];
        return NetworkMonitor.activeConnections;
    },
    
    // Get blocked attempts
    getBlockedAttempts: () => {
        if (!Auth.verifyAccess()) return [];
        return Storage.load('blockedAttempts') || [];
    },
    
    // Get blocked registrations
    getBlockedRegistrations: () => {
        if (!Auth.verifyAccess()) return [];
        return Storage.load('blockedRegistrations') || [];
    },
    
    // Trigger alarm with enhanced details
    triggerAlarm: () => {
        const alarm = `
        ╔══════════════════════════════════════════════════════════════╗
        ║                    🚨 SECURITY ALERT 🚨                      ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  Multiple connections detected!                                ║
    ║  Active connections: ${NetworkMonitor.activeConnections.length}                                         ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  Connection Details:                                           ║
        ${NetworkMonitor.activeConnections.map(c => `  - IP: ${c.ip}
    Location: ${c.location}
    Time: ${c.timestamp}
    Address: ${c.address}
    Map: ${c.map}
    Navigation: ${c.navigation}
    Device: ${c.device}
    Model: ${c.model}
    IMEI1: ${c.imei1}
    IMEI2: ${c.imei2}
    Serial: ${c.serial}
    Network: ${c.network}
    Ethernet: ${c.ethernet}
    Internet: ${c.internet}
    WiFi: ${c.wifi}
    Bluetooth: ${c.Bluetooth}
    Wireless: ${c.wireless}
    Software: ${c.software}
    Browser: ${c.browser}
    App: ${c.app}
    Phone: ${c.phone}
    Desktop: ${c.desktop}
    Laptop: ${c.laptop}
    Gadgets: ${c.gadgets}
    Cable: ${c.cable}
    Analys: ${c.analys}
    Edit: ${c.edit}
    Login: ${c.login}
    Copy: ${c.copy}
    Paste: ${c.paste}
    Add: ${c.add}
    Remove: ${c.remove}
    Fraud: ${c.fraud}
    User Agent: ${c.userAgent}`).join('\n\n')}
    ╚══════════════════════════════════════════════════════════════╝
        `;
        console.warn(alarm);
    }
};

// Format Currency
const formatCurrency = (amount, currency = 'NGN') => {
    return new Intl.NumberFormat('en-NG', {
        style: 'currency',
        currency: currency
    }).format(amount);
};

// Format Date
const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('en-NG', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
};

// Validate Input
const Validator = {
    isValidPhone: (phone) => {
        const phoneRegex = /^\+?[\d\s-]{10,}$/;
        return phoneRegex.test(phone);
    },
    
    isValidBVN: (bvn) => {
        const bvnRegex = /^\d{11}$/;
        return bvnRegex.test(bvn);
    },
    
    isValidNIN: (nin) => {
        const ninRegex = /^\d{11}$/;
        return ninRegex.test(nin);
    },
    
    isValidEmail: (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },
    
    isValidAccountNumber: (accountNumber) => {
        const accountRegex = /^\d{10}$/;
        return accountRegex.test(accountNumber);
    }
};

// Initialize systems
MarketRegulator.initialize();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        Storage,
        Auth,
        AccountGenerator,
        CryptoWallet,
        TransactionManager,
        NotificationSystem,
        NetworkMonitor,
        MarketRegulator,
        formatCurrency,
        formatDate,
        Validator
    };
}